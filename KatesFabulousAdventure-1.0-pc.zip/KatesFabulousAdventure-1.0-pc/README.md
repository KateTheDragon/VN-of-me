# Kates-Fabulous-Adventure
A cover letter/resume in Visual Novel form for a particularly fun-loving potential employer
